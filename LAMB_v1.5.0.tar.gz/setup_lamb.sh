#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

required=(
    "bin/modules/lamb.sh"
    "bin/modules/.lamb/io_utils.py"
    "bin/modules/.lamb/inventory_molecules.py"
    "bin/modules/.lamb/length_strata.py"
    "bin/modules/.lamb/solve_allocation.py"
    "bin/modules/.lamb/build_manifest.py"
    "bin/modules/.lamb/materialize_bams.py"
    "bin/modules/.lamb/validate_lamb.py"
    "bin/modules/.lamb/report_lamb.py"
    "bin/modules/.lamb/run_lamb.py"
    "bin/modules/.lamb/balance_lengths.py"
    "bin/modules/yaml/lamb.yml"
    "envs/yaml/lamb.yml"
    "docs/LAMB_OUTPUT_MANIFEST.md"
    "docs/LAMB_V1_MIGRATION.md"
)

for relative_path in "${required[@]}"; do
    [[ -f "$ROOT/$relative_path" ]] || {
        printf 'LAMB setup error: missing %s\n' "$ROOT/$relative_path" >&2
        exit 2
    }
done

chmod +x "$ROOT/bin/modules/lamb.sh"
find "$ROOT/bin/modules/.lamb" -maxdepth 1 -type f -name '*.py' -exec chmod +x {} +
chmod +x "$ROOT/setup_lamb.sh"

if [[ -f "$ROOT/bin/mapi" ]]; then
    chmod +x "$ROOT/bin/mapi"
fi

printf 'LAMB files are installed under: %s\n' "$ROOT"
printf 'MAPI runtime environment: %s\n' "$ROOT/bin/modules/yaml/lamb.yml"
printf 'Environment compatibility copy: %s\n' "$ROOT/envs/yaml/lamb.yml"
printf 'Wrapper: %s\n' "$ROOT/bin/modules/lamb.sh"
printf 'Output dictionary: %s\n' "$ROOT/docs/LAMB_OUTPUT_MANIFEST.md"
printf 'Migration guide: %s\n' "$ROOT/docs/LAMB_V1_MIGRATION.md"
printf 'Default workflow: inventory -> stratify -> allocate -> manifest -> validate -> report\n'
printf 'Optional physical BAMs: mapi lamb materialize --out-dir OUT\n'
printf 'Compatibility shortcut: balance (allocate + manifest)\n'
printf 'Run the complete workflow with: mapi lamb [OPTIONS]\n'
