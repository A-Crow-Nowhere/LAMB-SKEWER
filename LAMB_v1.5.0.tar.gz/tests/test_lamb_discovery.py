#!/usr/bin/env python3
"""Dependency-light tests for LAMB path and index discovery."""

import importlib.util
import os
import sys
import tempfile
import unittest
from pathlib import Path


MODULE_PATH = Path(__file__).parents[1] / "bin" / "modules" / ".lamb" / "io_utils.py"
SPEC = importlib.util.spec_from_file_location("io_utils", MODULE_PATH)
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


class DiscoveryTests(unittest.TestCase):
    def test_bai_naming_and_staleness(self):
        with tempfile.TemporaryDirectory() as tmp:
            bam = Path(tmp) / "sample.bam"
            bai = Path(f"{bam}.bai")
            bam.touch()
            bai.touch()
            path, kind, status = MODULE.resolve_index(bam)
            self.assertEqual(path, str(bai.resolve()))
            self.assertEqual(kind, "bai")
            self.assertEqual(status, "present")

    def test_stem_bai_is_recognized(self):
        with tempfile.TemporaryDirectory() as tmp:
            bam = Path(tmp) / "sample.bam"
            bai = Path(tmp) / "sample.bai"
            bam.touch()
            bai.touch()
            self.assertEqual(MODULE.resolve_index(bam)[0], str(bai.resolve()))

    def test_missing_index(self):
        with tempfile.TemporaryDirectory() as tmp:
            bam = Path(tmp) / "sample.bam"
            bam.touch()
            self.assertEqual(MODULE.resolve_index(bam), ("", "", "missing"))


if __name__ == "__main__":
    unittest.main()
