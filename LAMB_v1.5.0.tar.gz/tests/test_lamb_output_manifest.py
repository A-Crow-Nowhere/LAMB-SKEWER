#!/usr/bin/env python3
"""Contract checks for the running LAMB output dictionary."""

import unittest
from pathlib import Path


MANIFEST = Path(__file__).parents[1] / "docs" / "LAMB_OUTPUT_MANIFEST.md"


class OutputManifestTests(unittest.TestCase):
    def test_manifest_defines_project_specific_terms(self):
        text = MANIFEST.read_text(encoding="utf-8")
        required = (
            "molecule_id", "read_id", "read_length", "bin_id",
            "original_bin_n", "original_bin_fraction", "target_bin_n",
            "target_bin_fraction", "retention_probability",
            "normalization_weight", "target_bin_quota", "virtual_rank",
            "virtual_selected", "target_sample_n", "active_bin",
            "Minimalist", "Maximalist", "Valid checkpoint",
            "validation_report.tsv", "lamb_report.html", "mode_comparison.tsv",
            "min_read_length", "max_read_length", "min_bin_molecules",
            "below_min_bin_molecules", "below_min_read_length",
            "above_max_read_length",
            "sparse_bin_policy", "candidate_strata_merged",
            "minimum_sample_molecules", "per_sample/*.png",
            "adaptive_merge_all_bins_active",
            "materialization.tsv", "materialization_summary.json",
            "virtual_selected=1", "output_primary_molecules",
        )
        for term in required:
            with self.subTest(term=term):
                self.assertIn(term, text)

    def test_manifest_states_coordinate_convention(self):
        text = MANIFEST.read_text(encoding="utf-8")
        self.assertIn("zero-based and half-open", text)
        self.assertIn("interval_length = end - start", text)


if __name__ == "__main__":
    unittest.main()
