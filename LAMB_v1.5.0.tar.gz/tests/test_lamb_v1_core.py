#!/usr/bin/env python3
"""Core contract tests for molecule-centric LAMB 1.0."""

import csv
import gzip
import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest
from collections import Counter, defaultdict
from pathlib import Path
from unittest import mock

try:
    import pysam
except ImportError:
    pysam = None


IMPL = Path(__file__).parents[1] / "bin" / "modules" / ".lamb"
sys.path.insert(0, str(IMPL))


def load(name):
    spec = importlib.util.spec_from_file_location(name, IMPL / f"{name}.py")
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


INVENTORY = load("inventory_molecules")
STRATA = load("length_strata")
BALANCE = load("balance_lengths")
ALLOCATE = load("solve_allocation")
VALIDATE = load("validate_lamb")
REPORT = load("report_lamb")
MATERIALIZE = load("materialize_bams")
RUN = load("run_lamb")


class Entry:
    sample_id = "S1"


class Record:
    query_name = "read1"
    query_length = 5000
    is_duplicate = False
    is_qcfail = False
    is_unmapped = False
    mapping_quality = 30
    reference_name = "chr1"
    reference_start = 100
    reference_end = 5100
    is_reverse = False


class LambV1Tests(unittest.TestCase):
    @unittest.skipIf(pysam is None, "pysam is required for BAM end-to-end test")
    def test_default_wrapper_runs_complete_first_analysis(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            bam_dir = root / "bams"
            bam_dir.mkdir()
            header = {"HD": {"VN": "1.6"}, "SQ": [{"SN": "chr1", "LN": 10000}]}
            for sample, lengths in {
                "A": [100, 120, 300, 320],
                "B": [100, 120, 140, 300, 320, 340],
            }.items():
                with pysam.AlignmentFile(bam_dir / f"{sample}.bam", "wb", header=header) as bam:
                    for number, length in enumerate(lengths):
                        record = pysam.AlignedSegment()
                        record.query_name = f"read{number}"
                        record.query_sequence = "A" * length
                        record.flag = 0
                        record.reference_id = 0
                        record.reference_start = number * 500
                        record.mapping_quality = 60
                        record.cigar = [(0, length)]
                        record.query_qualities = pysam.qualitystring_to_array("I" * length)
                        bam.write(record)
            out = root / "out"
            wrapper = Path(__file__).parents[1] / "bin" / "modules" / "lamb.sh"
            command = [
                str(wrapper), "--bam-dir", str(bam_dir), "--length-strata", "2",
                "--mode", "maximalist", "--threads", "1", "--report-dpi", "72",
                "--out-dir", str(out),
            ]
            completed = subprocess.run(command, check=False, capture_output=True, text=True)
            self.assertEqual(completed.returncode, 0, completed.stderr)
            self.assertTrue((out / "03_model" / "lamb.model.json").is_file())
            self.assertTrue((out / "04_manifest" / "molecule_manifest.tsv.gz").is_file())
            self.assertTrue((out / "05_validation" / "validation_summary.json").is_file())
            self.assertTrue((out / "06_report" / "lamb_report.html").is_file())
            repeated = subprocess.run(command, check=False, capture_output=True, text=True)
            self.assertEqual(repeated.returncode, 0, repeated.stderr)
            self.assertIn("skipping", repeated.stderr)

    def test_mapping_diagnostic_does_not_control_length_eligibility(self):
        record = Record()
        record.is_unmapped = True
        values = INVENTORY.molecule_values(Entry(), record, 20)
        self.assertEqual(values[12], 1)
        self.assertEqual(values[14], 0)

    def test_quantile_length_strata_are_half_open(self):
        edges = STRATA.quantile_edges({1000: 10, 2000: 10, 3000: 10, 4000: 10}, 2)
        self.assertEqual(edges[0], 1000)
        self.assertEqual(edges[-1], 4001)
        for length in (1000, 2000, 3000, 4000):
            index = STRATA.stratum_index(edges, length)
            self.assertTrue(edges[index] <= length < edges[index + 1])

    def test_stratify_and_balance_length_only(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp)
            (out / "inventory_summary.json").write_text(json.dumps({"schema_version": "2.0"}))
            with (out / "bam_manifest.tsv").open("w", newline="") as handle:
                writer = csv.DictWriter(
                    handle,
                    fieldnames=["sample_id", "bam_path", "bam_size_bytes", "bam_mtime_utc",
                                "index_path", "index_type", "index_status", "source"],
                    delimiter="\t",
                )
                writer.writeheader()
                for sample in ("A", "B"):
                    writer.writerow({
                        "sample_id": sample, "bam_path": f"/{sample}.bam",
                        "bam_size_bytes": 1, "bam_mtime_utc": "2026-01-01T00:00:00+00:00",
                        "index_path": "", "index_type": "", "index_status": "missing",
                        "source": "test",
                    })
            (out / "sample_inventory.tsv").write_text("sample_id\nA\nB\n")
            fields = INVENTORY.MOLECULE_FIELDS
            with gzip.open(out / "molecule_inventory.tsv.gz", "wt", newline="") as handle:
                writer = csv.DictWriter(handle, fieldnames=fields, delimiter="\t")
                writer.writeheader()
                for sample, lengths in {"A": [1000, 1100, 3000, 3100], "B": [1000, 1200, 1300, 3000, 3100, 3200]}.items():
                    for number, length in enumerate(lengths):
                        writer.writerow(dict(
                            sample_id=sample, molecule_id=f"{sample}::r{number}", query_name=f"r{number}",
                            query_length=length, primary_mapped=int(number % 2 == 0), mapq=30,
                            reference="chr1", reference_start=0, reference_end=length,
                            is_reverse=0, is_duplicate=0, is_qcfail=0,
                            length_allocation_eligible=1, length_exclusion_reason="eligible",
                            mapping_diagnostic_pass=int(number % 2 == 0),
                        ))
            self.assertEqual(STRATA.main(["--out-dir", str(out), "--length-strata", "2"]), 0)
            self.assertEqual(BALANCE.main(["--out-dir", str(out)]), 0)
            self.assertEqual(STRATA.main(["--out-dir", str(out), "--length-strata", "2"]), 0)
            self.assertEqual(BALANCE.main(["--out-dir", str(out)]), 0)
            model = json.loads((out / "03_model" / "lamb.model.json").read_text())
            self.assertFalse(model["mapping_affects_weight"])
            self.assertEqual(model["mode"], "minimalist")
            with gzip.open(out / "04_manifest" / "molecule_manifest.tsv.gz", "rt", newline="") as handle:
                rows = list(csv.DictReader(handle, delimiter="\t"))
            with (out / "03_model" / "allocation.tsv").open(newline="") as handle:
                allocation_rows = list(csv.DictReader(handle, delimiter="\t"))
            for row in rows:
                self.assertEqual(row["retention_probability"], row["normalization_weight"])
            expected_selected = {
                (row["sample_id"], row["length_stratum_id"]): int(row["target_bin_quota"])
                for row in allocation_rows
            }
            observed_selected = {}
            for row in rows:
                key = (row["sample_id"], row["bin_id"])
                observed_selected[key] = observed_selected.get(key, 0) + int(row["virtual_selected"])
            self.assertEqual(observed_selected, expected_selected)
            selected_ids = {
                row["molecule_id"] for row in rows if int(row["virtual_selected"])
            }
            totals = {}
            for row in rows:
                key = (row["sample_id"], row["bin_id"])
                totals[key] = totals.get(key, 0.0) + float(row["normalization_weight"])
            by_stratum = {}
            for (sample, stratum), total in totals.items():
                by_stratum.setdefault(stratum, []).append(round(total, 10))
            for values in by_stratum.values():
                self.assertEqual(len(set(values)), 1)
            self.assertEqual(BALANCE.main(["--out-dir", str(out), "--overwrite"]), 0)
            with gzip.open(out / "04_manifest" / "molecule_manifest.tsv.gz", "rt", newline="") as handle:
                rebuilt_rows = list(csv.DictReader(handle, delimiter="\t"))
            self.assertEqual(
                selected_ids,
                {row["molecule_id"] for row in rebuilt_rows if int(row["virtual_selected"])},
            )
            self.assertEqual(VALIDATE.main(["--out-dir", str(out)]), 0)
            validation = json.loads((out / "05_validation" / "validation_summary.json").read_text())
            self.assertEqual(validation["status"], "PASS")
            self.assertEqual(REPORT.main(["--out-dir", str(out), "--dpi", "72"]), 0)
            report_html = (out / "06_report" / "lamb_report.html").read_text()
            self.assertIn("LAMB normalization report", report_html)
            self.assertIn("Per-sample original and corrected profiles", report_html)
            self.assertTrue((out / "06_report" / "mode_comparison.png").is_file())
            self.assertEqual(len(list((out / "06_report" / "per_sample").glob("*.png"))), 2)
            self.assertEqual(RUN.main(["--out-dir", str(out)]), 0)
            wrapper = Path(__file__).parents[1] / "bin" / "modules" / "lamb.sh"
            completed = subprocess.run(
                [str(wrapper), "--out-dir", str(out)],
                check=False, capture_output=True, text=True,
            )
            self.assertEqual(completed.returncode, 0, completed.stderr)
            self.assertIn("Complete workflow finished", completed.stderr)
            self.assertEqual(VALIDATE.main(["--out-dir", str(out), "--deep", "--overwrite"]), 0)
            deep_validation = json.loads((out / "05_validation" / "validation_summary.json").read_text())
            self.assertTrue(deep_validation["deep_validation"])
            self.assertEqual(RUN.main([
                "--out-dir", str(out), "--length-strata", "2",
                "--min-read-length", "1100", "--max-read-length", "3100",
                "--min-bin-molecules", "1", "--report-dpi", "72", "--overwrite",
            ]), 0)
            range_summary = json.loads((out / "stratification_summary.json").read_text())
            self.assertEqual(range_summary["range_excluded_molecule_count"], 3)
            self.assertEqual(range_summary["min_read_length"], 1100)
            self.assertEqual(range_summary["max_read_length"], 3100)
            with gzip.open(out / "04_manifest" / "molecule_manifest.tsv.gz", "rt", newline="") as handle:
                ranged_manifest = list(csv.DictReader(handle, delimiter="\t"))
            range_exclusions = [
                row for row in ranged_manifest
                if row["length_exclusion_reason"] in ("below_min_read_length", "above_max_read_length")
            ]
            self.assertEqual(len(range_exclusions), 3)
            self.assertTrue(all(row["normalization_weight"] == "0" for row in range_exclusions))

    def test_maximalist_improves_worst_retention_and_allows_different_totals(self):
        samples = ["A", "B"]
        bins = ["L001", "L002"]
        counts = {
            ("A", "L001"): 80, ("A", "L002"): 20,
            ("B", "L001"): 100, ("B", "L002"): 100,
        }
        fractions, targets, optimizer = ALLOCATE.solve_maximalist(samples, bins, counts)
        self.assertAlmostEqual(fractions["L001"], 5 / 7)
        self.assertAlmostEqual(fractions["L002"], 2 / 7)
        self.assertAlmostEqual(sum(targets["A"].values()), 70)
        self.assertAlmostEqual(sum(targets["B"].values()), 140)
        self.assertAlmostEqual(optimizer["primary_optimum"], 0.7)
        minimalist_worst = (80 + 20) / 200
        self.assertGreater(optimizer["primary_optimum"], minimalist_worst)

    def test_maximalist_optimum_matches_two_bin_grid_search(self):
        samples = ["A", "B", "C"]
        bins = ["L001", "L002"]
        counts = {
            ("A", "L001"): 70, ("A", "L002"): 30,
            ("B", "L001"): 40, ("B", "L002"): 60,
            ("C", "L001"): 90, ("C", "L002"): 110,
        }
        fractions, _, optimizer = ALLOCATE.solve_maximalist(samples, bins, counts)
        computed = optimizer["primary_optimum"]
        grid_best = 0.0
        for step in range(1, 1000):
            p1 = step / 1000
            p2 = 1 - p1
            worst = min(
                min(
                    counts[(sample, "L001")] / (sum(counts[(sample, b)] for b in bins) * p1),
                    counts[(sample, "L002")] / (sum(counts[(sample, b)] for b in bins) * p2),
                )
                for sample in samples
            )
            grid_best = max(grid_best, worst)
        self.assertGreaterEqual(computed + 1e-12, grid_best)
        self.assertAlmostEqual(sum(fractions.values()), 1.0)

    def test_maximalist_deactivates_bin_missing_from_any_sample(self):
        samples = ["A", "B"]
        bins = ["L001", "L002", "L003"]
        counts = {
            ("A", "L001"): 50, ("A", "L002"): 50, ("A", "L003"): 0,
            ("B", "L001"): 25, ("B", "L002"): 25, ("B", "L003"): 50,
        }
        fractions, targets, _ = ALLOCATE.solve_maximalist(samples, bins, counts)
        self.assertEqual(fractions["L003"], 0.0)
        self.assertEqual(targets["A"]["L003"], 0.0)
        self.assertEqual(targets["B"]["L003"], 0.0)

    def test_minimum_bin_occupancy_deactivates_sparse_bin(self):
        samples = ["A", "B"]
        bins = ["L001", "L002"]
        counts = {
            ("A", "L001"): 10, ("A", "L002"): 2,
            ("B", "L001"): 20, ("B", "L002"): 100,
        }
        for solver in (ALLOCATE.solve_minimalist, ALLOCATE.solve_maximalist):
            fractions, targets, _ = solver(samples, bins, counts, min_bin_molecules=3)
            self.assertEqual(fractions["L001"], 1.0)
            self.assertEqual(fractions["L002"], 0.0)
            self.assertEqual(targets["A"]["L002"], 0.0)
            self.assertEqual(targets["B"]["L002"], 0.0)

    def test_read_length_range_is_inclusive(self):
        self.assertFalse(STRATA.in_model_range(999, 1000, 5000))
        self.assertTrue(STRATA.in_model_range(1000, 1000, 5000))
        self.assertTrue(STRATA.in_model_range(5000, 1000, 5000))
        self.assertFalse(STRATA.in_model_range(5001, 1000, 5000))
        self.assertTrue(STRATA.in_model_range(5001, 1000, None))

    def test_sparse_candidate_bins_merge_into_supported_shared_bins(self):
        counts = defaultdict(Counter)
        for sample, values in {
            "A": [5, 0, 0, 5],
            "B": [0, 5, 5, 0],
        }.items():
            for index, value in enumerate(values):
                counts[(sample, index)]["eligible"] = value
        groups = STRATA.sparse_merge_groups(counts, ["A", "B"], 4, 1)
        self.assertEqual(groups, [(0, 2), (2, 4)])

    def test_adaptive_stratification_prevents_zero_weight_tail(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp)
            (out / "inventory_summary.json").write_text('{"schema_version":"2.0"}\n')
            with (out / "bam_manifest.tsv").open("w", newline="") as handle:
                writer = csv.DictWriter(handle, fieldnames=["sample_id"], delimiter="\t")
                writer.writeheader()
                writer.writerows([{"sample_id": "A"}, {"sample_id": "B"}])
            with gzip.open(out / "molecule_inventory.tsv.gz", "wt", newline="") as handle:
                writer = csv.DictWriter(handle, fieldnames=INVENTORY.MOLECULE_FIELDS, delimiter="\t")
                writer.writeheader()
                for sample, lengths in {"A": [100, 100, 400, 400], "B": [200, 200, 300, 300]}.items():
                    for number, length in enumerate(lengths):
                        writer.writerow({
                            "sample_id": sample, "molecule_id": f"{sample}::r{number}",
                            "query_name": f"r{number}", "query_length": length,
                            "primary_mapped": 1, "mapq": 60, "reference": "chr1",
                            "reference_start": 0, "reference_end": length, "is_reverse": 0,
                            "is_duplicate": 0, "is_qcfail": 0,
                            "length_allocation_eligible": 1,
                            "length_exclusion_reason": "eligible", "mapping_diagnostic_pass": 1,
                        })
            self.assertEqual(STRATA.main([
                "--out-dir", str(out), "--length-strata", "4",
                "--sparse-bin-policy", "merge", "--min-bin-molecules", "1",
            ]), 0)
            summary = json.loads((out / "stratification_summary.json").read_text())
            self.assertEqual(summary["candidate_length_strata"], 4)
            self.assertEqual(summary["actual_length_strata"], 2)
            self.assertEqual(summary["zero_sample_stratum_cells"], [])
            self.assertEqual(ALLOCATE.main([
                "--out-dir", str(out), "--mode", "maximalist", "--min-bin-molecules", "1",
            ]), 0)
            with (out / "03_model" / "allocation.tsv").open(newline="") as handle:
                rows = list(csv.DictReader(handle, delimiter="\t"))
            self.assertTrue(all(int(row["active_bin"]) == 1 for row in rows))
            self.assertTrue(all(float(row["normalization_weight"]) > 0 for row in rows))

    def test_integer_quotas_are_exact_and_capacity_bounded(self):
        quotas = ALLOCATE.conservative_integer_quotas(
            {"L001": 3.6, "L002": 2.6}, {"L001": 4, "L002": 3}
        )
        self.assertEqual(sum(quotas.values()), 6)
        self.assertLessEqual(quotas["L001"], 4)
        self.assertLessEqual(quotas["L002"], 3)

    def test_materialization_exports_exact_selected_read_names(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            manifest = root / "molecule_manifest.tsv.gz"
            with gzip.open(manifest, "wt", newline="") as handle:
                writer = csv.DictWriter(
                    handle,
                    fieldnames=["sample_id", "read_id", "virtual_selected"],
                    delimiter="\t",
                )
                writer.writeheader()
                writer.writerows([
                    {"sample_id": "A", "read_id": "a1", "virtual_selected": 1},
                    {"sample_id": "A", "read_id": "a2", "virtual_selected": 0},
                    {"sample_id": "B/sample", "read_id": "b1", "virtual_selected": 1},
                    {"sample_id": "B/sample", "read_id": "b2", "virtual_selected": 1},
                ])
            samples = ["A", "B/sample"]
            stems = MATERIALIZE.safe_sample_stems(samples)
            self.assertEqual(stems["A"], "A")
            self.assertNotIn("/", stems["B/sample"])
            paths, counts = MATERIALIZE.export_selected_read_names(
                manifest, root / "names", stems,
            )
            self.assertEqual(counts, {"A": 1, "B/sample": 2})
            self.assertEqual(paths["A"].read_text().splitlines(), ["a1"])
            self.assertEqual(paths["B/sample"].read_text().splitlines(), ["b1", "b2"])

    def test_materialization_stage_verifies_and_checkpoints_outputs(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp)
            input_bam = out / "A.bam"
            input_index = out / "A.bam.bai"
            input_bam.write_bytes(b"input-bam")
            input_index.write_bytes(b"input-index")
            with (out / "bam_manifest.tsv").open("w", newline="") as handle:
                writer = csv.DictWriter(
                    handle, fieldnames=["sample_id", "bam_path", "index_path"],
                    delimiter="\t",
                )
                writer.writeheader()
                writer.writerow({
                    "sample_id": "A", "bam_path": input_bam,
                    "index_path": input_index,
                })
            manifest_dir = out / "04_manifest"
            manifest_dir.mkdir()
            with gzip.open(manifest_dir / "molecule_manifest.tsv.gz", "wt", newline="") as handle:
                writer = csv.DictWriter(
                    handle, fieldnames=["sample_id", "read_id", "virtual_selected"],
                    delimiter="\t",
                )
                writer.writeheader()
                writer.writerow({"sample_id": "A", "read_id": "read1", "virtual_selected": 1})
                writer.writerow({"sample_id": "A", "read_id": "read2", "virtual_selected": 0})
            (manifest_dir / "manifest_summary.json").write_text(json.dumps({
                "virtual_selected_by_sample": {"A": 1},
            }))

            def fake_samtools(command):
                if command[1:] == ["--version"]:
                    return "samtools 1.17\n"
                if command[1:3] == ["view", "-H"]:
                    return "@HD\tVN:1.6\tSO:coordinate\n"
                if command[1] == "view" and "-o" in command:
                    Path(command[command.index("-o") + 1]).write_bytes(b"normalized-bam")
                    return ""
                if command[1] == "index":
                    Path(command[-1]).write_bytes(b"normalized-index")
                    return ""
                if command[1:3] == ["quickcheck", "-v"]:
                    return ""
                if command[1:3] == ["view", "-c"]:
                    return "1\n" if "-F" in command else "2\n"
                raise AssertionError(command)

            with mock.patch.object(MATERIALIZE.shutil, "which", return_value="/fake/samtools"), \
                    mock.patch.object(MATERIALIZE, "run_command", side_effect=fake_samtools):
                self.assertEqual(MATERIALIZE.main(["--out-dir", str(out)]), 0)
                self.assertEqual(MATERIALIZE.main(["--out-dir", str(out)]), 0)
            summary = json.loads(
                (out / "07_materialized_bams" / "materialization_summary.json").read_text()
            )
            self.assertEqual(summary["status"], "PASS")
            self.assertEqual(summary["selected_molecules"], 1)
            self.assertEqual(summary["output_alignment_records"], 2)
            self.assertTrue(Path(summary["samples"][0]["output_bam"]).is_file())
            self.assertTrue(Path(summary["samples"][0]["output_index"]).is_file())


if __name__ == "__main__":
    unittest.main()
