# LAMB Output Manifest and Data Dictionary

Manifest version: 1.5.0  
Applies to: LAMB 1.5.x  
Last updated: 2026-08-18

LAMB normalizes differences in molecule-length composition across long-read
datasets while preserving every physical molecule. Mapping statistics are
diagnostic only and never alter allocation.

## Core workflow

```text
inventory -> stratify -> allocate -> manifest -> validate -> report
```

Optional physical materialization branches from the deterministic manifest:

```text
manifest -> materialize selected BAMs -> validate -> report
```

Running `mapi lamb [OPTIONS]` or `mapi lamb run [OPTIONS]` executes this whole
workflow and reuses every valid checkpoint. Each named stage remains callable
independently. A resume containing only `--out-dir` reuses the existing bin
count, allocation mode, seed, and report resolution.

`balance` is a compatibility shortcut that runs `allocate` followed by
`manifest`.

## Core terminology

### Physical molecule

For the intended single-molecule long-read BAM, one primary BAM record
represents one physical sequenced molecule. Secondary and supplementary
alignment records are evidence for that molecule and are not counted again.

```text
molecule_id = sample_id + "::" + read_id
```

`read_id` is the BAM query name. `molecule_id` is globally disambiguated by
sample.

### Length bin

A LAMB bin is a shared read-length interval:

```text
[lower_length_inclusive, upper_length_exclusive)
```

The interval convention is zero-based and half-open only when genomic
coordinates are reported. For any half-open interval:

```text
interval_length = end - start
```

Length bins are not genomic windows. Their values are molecule lengths in
bases. `stratify` first creates shared candidate edges from pooled
molecule-count quantiles. With the default `--sparse-bin-policy merge`, it then
merges adjacent candidate intervals until every sample has at least
`min_bin_molecules` in every final interval. The final edges are shared and
fixed before allocation; the allocator does not move, split, or merge them.

The requested number is therefore a maximum candidate-bin count. The actual
number can be smaller because identical lengths collapse quantile edges or
because sparse adjacent candidates are adaptively merged. LAMB never adds a
pseudocount or invents a molecule to support a bin.

### Active bin

An active bin has a positive target fraction:

```text
active_bin = 1 when target_bin_fraction > 0
```

With the default adaptive merge policy, every final bin must be active and
must have support in every sample. This is checked immediately after solving
and again by validation.

The generalized occupancy rule is:

```text
active_bin = 1 only when N[s,b] >= min_bin_molecules for every sample s
```

`min_bin_molecules` defaults to 1, which protects against zero-count cells.
Increasing it makes the adaptive bins more conservative. If a candidate bin
does not meet the threshold in every sample, LAMB combines it with one or more
adjacent candidates before allocation. A final bin can consequently be wide
where samples have little overlapping length support.

`--sparse-bin-policy deactivate` retains the earlier behavior: candidate edges
remain unchanged and any bin below the threshold in one or more samples is
globally inactive, with zero target count, quota, and normalization weight.
This compatibility policy can produce the zero-weight tail that adaptive
merging is designed to avoid.

### Statistical target and physical quota

`target_bin_n` is the model's statistical target and may be noninteger in
Maximalist mode. `target_bin_quota` is the deterministic integer count used by
`virtual_selected` and by optional normalized-BAM materialization.

Maximalist quotas are formed conservatively: floor the sample target total,
then distribute the remaining integer units by largest fractional remainder,
with `bin_id` as the stable tie breaker. Every quota is bounded by the observed
bin count.

## Eligibility and mapping policy

A primary molecule is length-allocation eligible when:

```text
read_length > 0
AND not marked duplicate
AND not marked QC-fail
```

The stratification stage can additionally restrict the modeled length range:

```text
min_read_length <= read_length <= max_read_length
```

Both limits are inclusive. `--min-read-length` defaults to 1 and
`--max-read-length` defaults to unlimited. Out-of-range molecules remain in the
all-molecule manifest with `below_min_read_length` or
`above_max_read_length`, a blank `bin_id`, and normalization weight 0.

Mapped status and MAPQ do not determine length-allocation eligibility. Mapping
rate and the configured MAPQ-pass rate are carried as diagnostics only:

```text
mapping_affects_weight = false
```

There is no `mapped_length_weight`.

## Allocation mathematics

Let:

```text
N[s,b] = eligible molecule count for sample s and fixed length bin b
N[s]   = sum over b of N[s,b]
```

### Minimalist mode

For every fixed bin:

```text
T[b] = minimum over samples s of N[s,b]
```

Every sample receives the same target count in every bin. Therefore all
samples have identical target bin counts, target length fractions, and total
target molecule counts.

```text
target_bin_n[s,b] = T[b]
normalization_weight[s,b] = T[b] / N[s,b]
```

### Maximalist mode

Define the original bin fraction:

```text
q[s,b] = N[s,b] / N[s]
```

The primary objective maximizes the retention fraction of the worst-treated
sample. For the shared fixed-bin problem without additional occupancy
constraints, define:

```text
x[b] = minimum over samples s of q[s,b]
r*   = sum over b of x[b]
P[b] = x[b] / r*
```

`r*` is the optimal worst-sample retention fraction and `P[b]` is the common
target length distribution. Bins with `P[b] = 0` are inactive.

While maintaining that distribution, the secondary objective maximizes each
sample's retained total:

```text
T[s] = minimum over active bins b of N[s,b] / P[b]
target_bin_n[s,b] = T[s] * P[b]
```

Maximalist samples therefore have identical target fractions but can have
different target totals. Downstream software should carry `target_sample_n` as
the sample exposure.

### Retention probability and normalization weight

For either mode:

```text
retention_probability[s,b]
    = target_bin_n[s,b] / original_bin_n[s,b]

normalization_weight[s,b]
    = retention_probability[s,b]
```

This is a retained-mass weight between 0 and 1, not an inverse-probability
survey weight.

## Deterministic virtual selection

Every molecule receives a SHA-256 value from the byte serialization:

```text
lamb-v1 NUL seed NUL sample_id NUL molecule_id
```

Eligible molecules are sorted by hash, then `molecule_id`, within each sample
and fixed length bin. The one-based ordinal is `virtual_rank`.

```text
virtual_selected = 1 when virtual_rank <= target_bin_quota
```

The seed, hash algorithm, serialization, quotas, and rank rule are recorded in
the model or manifest summary. Repeated runs with identical inputs and seed
select exactly the same molecules without relying on RNG state.

The statistical all-read workflow remains the default. `mapi lamb materialize`
or the full-run flag `--materialize-bams` converts the existing
`virtual_selected` decisions into physical BAM files without making a new
random selection.

## Inventory and stratification outputs

### `bam_manifest.tsv`

One row per discovered BAM. It records `sample_id`, resolved BAM path, file
size, modification time, index path/type/status, and discovery source. These
values form the input BAM signatures stored in the model.

### `molecule_inventory.tsv.gz`

One row per physical molecule. Important columns include `molecule_id`, BAM
query name, query length, length eligibility and exclusion reason, primary
mapping placement, MAPQ, and mapping diagnostic pass. This inventory is reused
by `manifest`; the BAM is not reread.

### `sample_inventory.tsv`

One row per sample with BAM-record counts, primary-molecule counts, molecule
length summaries, eligibility counts, and mapping diagnostics.

### `length_strata.tsv`

One row per final shared fixed length bin, with the lower-inclusive and
upper-exclusive length edges, number of candidate strata incorporated,
minimum sample occupancy, pooled eligible count, and pooled fraction. Only
molecules within the configured inclusive read-length range are used to
construct candidate quantiles. `stratification_summary.json` records both
limits, the candidate and final bin counts, the merge groups, sparse-bin
policy (`sparse_bin_policy`), threshold, and per-sample number of
range-excluded molecules.

Important columns are:

| Column | Definition |
| --- | --- |
| `candidate_strata_merged` | Number of adjacent candidate quantile intervals represented by this final bin. A value of 1 means no merge was needed. |
| `minimum_sample_molecules` | Smallest eligible molecule count observed in this final bin among all samples. Under `merge`, this is at least `min_bin_molecules`. |

### `sample_length_composition.tsv`

One row per sample and fixed length bin, including zero-count cells. The core
count is `allocation_eligible_molecules`, or `N[s,b]`. Mapping columns remain
diagnostic.

## `03_model/` allocation outputs

### `03_model/allocation.tsv`

One row per sample and fixed length bin.

| Column | Definition |
| --- | --- |
| `active_bin` | `1` when the common target fraction is positive. |
| `bin_exclusion_reason` | `active` or `below_min_bin_molecules`. |
| `minimum_sample_bin_n` | Smallest observed count for this bin among all samples. |
| `original_bin_n` | Observed eligible count, `N[s,b]`. |
| `original_bin_fraction` | `N[s,b] / N[s]`. |
| `target_bin_n` | Statistical target count. |
| `target_bin_quota` | Exact deterministic physical-selection quota. |
| `target_bin_fraction` | Common target distribution, `P[b]`. |
| `retention_probability` | `target_bin_n / original_bin_n`. |
| `normalization_weight` | Exactly equal to `retention_probability`. |
| `original_sample_n` | Original eligible total, `N[s]`. |
| `target_sample_n` | Statistical target total, `T[s]`. |
| `target_sample_quota` | Sum of integer quotas for the sample. |
| `retention_fraction` | `target_sample_n / original_sample_n`. |
| `limiting_bin` | `1` for the bin imposing the highest retention probability for that sample. |

### `03_model/retention.tsv`

One row per sample containing original total, statistical target total,
integer target quota, retention fraction, and limiting bin ID.

### `03_model/lamb.model.json`

The reconstructable normalization decision. It records:

- LAMB and schema versions;
- Minimalist or Maximalist mode;
- input BAM signatures;
- seed;
- fixed bin edges and active status;
- original counts;
- statistical target counts and integer quotas;
- common target fractions;
- sample retention fractions;
- optimizer method, objectives, and settings;
- active constraints;
- explicit `mapping_affects_weight: false`; and
- upstream hashes and output paths.

## `04_manifest/` outputs

### `04_manifest/molecule_manifest.tsv.gz`

This is the LAMB-to-SKEWER interface contract. It contains every molecule,
including allocation-ineligible molecules.

| Column | Definition |
| --- | --- |
| `sample_id` | Stable sample label. |
| `molecule_id` | Sample-qualified physical molecule identifier. |
| `read_id` | Original BAM query name. |
| `read_length` | Primary-record query length in bases. |
| `bin_id` | Fixed length-bin ID; empty for ineligible molecules. |
| `length_allocation_eligible` | `1` when the molecule participates in allocation. |
| `length_exclusion_reason` | `eligible` or explicit semicolon-separated reasons. |
| `original_bin_n`, `original_bin_fraction` | Original count and composition of its sample-bin. |
| `target_bin_n`, `target_bin_fraction` | Statistical target count and common target composition. |
| `target_bin_quota` | Integer count selected from its sample-bin. |
| `retention_probability` | Statistical retained fraction for its sample-bin. |
| `normalization_weight` | Statistical contribution passed to SKEWER. |
| `virtual_hash_sha256` | Stable molecule hash. |
| `virtual_rank` | One-based hash rank within sample-bin; empty when ineligible. |
| `virtual_selected` | Exact deterministic physical-selection indicator. |
| `primary_mapped`, `mapq`, `mapping_diagnostic_pass` | Diagnostics that do not affect allocation. |

### `04_manifest/manifest_summary.json`

Records the model and inventory hashes, mode, seed, hashing contract, ranking
scope, selection rule, molecule counts, and per-sample virtual-selected totals.

## `05_validation/` outputs

### `05_validation/validation_report.tsv`

One row per contract check with `check`, `status`, and human-readable `details`.
The default validation is intentionally fast and checks model identity,
upstream hashes, the complete sample-bin matrix, target fractions, weight
equations, integer quotas, retention totals, and manifest summary totals.

`mapi lamb validate --deep` additionally streams every molecule-manifest row
and verifies its bin count, weight, hash rank selection rule, and selected
quota. Deep validation is optional because it requires another complete pass
through the large manifest.

### `05_validation/validation_summary.json`

Machine-readable overall `PASS` or `FAIL`, validation depth, check counts,
failed check names, input hashes, version, and output path.

If physical BAMs were produced from the current manifest, validation also
checks that their reported primary-record counts equal their exact selection
quotas and that every BAM and BAI still exists at its recorded size.

## `06_report/` outputs

### `06_report/lamb_report.html`

A self-contained readable index using local PNG files. It summarizes the
selected mode, sample count, active bins, worst-sample retention, validation
status, per-sample retention, and key interpretation rules.

### Plot and table outputs

| File | Contents |
| --- | --- |
| `raw_vs_target_length_composition.png` | Original sample length fractions and the selected common target. |
| `sample_retention.png` | Statistical retained fraction for every sample. |
| `retention_probability_heatmap.png` | Sample-by-length-bin normalization weights. |
| `mode_comparison.png` | Minimalist and Maximalist fairness and total-retention comparison. |
| `mode_comparison.tsv` | Exact values underlying the mode-comparison plot. |
| `report_summary.tsv` | Compact human-readable run metrics. |
| `per_sample/*.png` | Independently scaled plot for each sample, with original per-bin molecule counts as bars and corrected target molecule-equivalent counts as an overlaid line and area. |

The comparison report does not change the selected model and does not build a
second molecule manifest. The HTML tiles the `per_sample/*.png` plots in a
final section so small samples are not visually flattened by larger samples.
When current materialized BAMs exist, the report also lists their paths and
verified molecule and alignment-record counts.

## `07_materialized_bams/` optional physical outputs

Physical BAM creation is deliberately optional because the primary LAMB and
SKEWER contract preserves every molecule and carries statistical weights.
Materialization is useful for software that cannot consume those weights or
when an exactly normalized BAM is explicitly needed.

Run it as a separate checkpointed stage:

```bash
mapi lamb materialize \
  --out-dir .out/ \
  --threads 4
```

Or request it while running the complete workflow:

```bash
mapi lamb \
  --bam-dir ./bams \
  --mode maximalist \
  --materialize-bams \
  --threads 4 \
  --out-dir .out/
```

For each sample, LAMB writes:

```text
07_materialized_bams/<sample>.lamb.normalized.bam
07_materialized_bams/<sample>.lamb.normalized.bam.bai
```

Selection is by BAM query name. If a molecule has `virtual_selected=1`, all
records with that query name are retained, including its primary,
supplementary, and secondary alignments. This preserves split-read and other
structural evidence for every selected molecule. Molecules with
`virtual_selected=0` are absent from the physical BAM.

The source BAM must be coordinate sorted or have an existing index that proves
it is indexable. For each output, LAMB:

1. writes the exact selected read-name set from the manifest;
2. runs `samtools view -N` without alignment-type filtering;
3. creates a BAI with `samtools index`;
4. runs `samtools quickcheck`; and
5. confirms `output_primary_molecules == selected_molecules_requested`.

The temporary read-name lists are removed after successful materialization.
The manifest remains the permanent record of the exact selection.

### `07_materialized_bams/materialization.tsv`

One row per sample. Important columns include:

| Column | Definition |
| --- | --- |
| `input_bam` | Original BAM recorded during inventory. |
| `output_bam`, `output_index` | Absolute paths to the normalized BAM and BAI. |
| `selected_molecules_requested` | Number of manifest molecules with `virtual_selected=1`. |
| `output_primary_molecules` | Number of nonsecondary, nonsupplementary records found in the output BAM. This must equal the requested count. |
| `output_alignment_records` | All retained BAM records, including supplementary and secondary records belonging to selected molecules. |
| `selection_policy` | Written rule used to translate the manifest into the BAM. |

### `07_materialized_bams/materialization_summary.json`

Machine-readable `PASS` record containing the LAMB and samtools versions,
manifest hashes, live input-BAM fingerprint, compression setting, output
paths and sizes, per-sample counts, and the alignment-record retention policy.
These fields form the physical-BAM checkpoint.

## Checkpoints

A **Valid checkpoint** requires all stage outputs plus matching schema,
upstream fingerprint, and behavior-changing options.

- Inventory checks BAM signatures and the diagnostic MAPQ threshold.
- Stratification checks the inventory summary, requested candidate-bin count,
  inclusive minimum and maximum read lengths, sparse-bin policy, and minimum
  per-sample bin occupancy.
- Allocation checks the stratification summary, mode, seed, minimum per-sample
  bin occupancy, shared-fixed-edge policy, and length-only weighting policy.
- Manifest checks the allocation model, inventory summary, and hash contract.
- Validation checks the final cross-file contract and records whether a full
  molecule-row audit was requested.
- Report checks the model, allocation, composition, and validation hashes plus
  the requested plot resolution.
- Physical materialization checks the molecule manifest, BAM manifest, live
  input BAM signatures, compression setting, output paths, sizes, and indexes.

When adaptive merging is selected, the
`adaptive_merge_all_bins_active` check requires every final length bin to have
a positive common target and normalization weight.

An unchanged rerun skips completed stages. `--overwrite` explicitly rebuilds
the requested stage.

## Revision history

| Manifest version | Date | Change |
| --- | --- | --- |
| 1.5.0 | 2026-08-18 | Added optional deterministic physical-BAM materialization with all-record query-name retention, BAI creation, samtools integrity checks, exact primary-molecule count verification, checkpoints, validation integration, and HTML reporting. |
| 1.4.0 | 2026-08-17 | Made adaptive adjacent merging the default sparse-bin policy, added post-solve and validation invariants requiring all adaptively merged final bins to be active, and added tiled independently scaled per-sample original-versus-corrected plots. |
| 1.3.0 | 2026-08-17 | Added inclusive minimum and maximum modeled read lengths plus a minimum per-sample bin occupancy constraint. Sparse bins remain visible but receive zero target, quota, and normalization weight. |
| 1.2.1 | 2026-08-17 | Simplified the packaged MAPI YAML files to requirements-only Conda environment specifications. |
| 1.2.0 | 2026-08-17 | Made the complete workflow the default command, added fast and deep validation, and added readable HTML, PNG, and TSV reporting. Removed the retired genomic-window prototype from the distribution. |
| 1.1.0 | 2026-08-17 | Added Minimalist and Maximalist allocation models, reconstructable `03_model` outputs, exact deterministic integer quotas, and the all-molecule `04_manifest` interface. |
| 1.0.0 | 2026-08-14 | Rebuilt LAMB around physical molecules, shared read-length strata, and mapping-independent cross-sample weights. |
