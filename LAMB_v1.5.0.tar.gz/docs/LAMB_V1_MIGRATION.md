# Migrating the LAMB prototype to molecule-centric LAMB

LAMB 1.0 changes the core meaning of normalization from genomic-window depth
correction to cross-sample read-length-composition balancing.

The LAMB 1.5 public statistical workflow is:

```text
inventory -> stratify -> allocate -> manifest -> validate -> report
```

The complete workflow is now the default. A new analysis normally needs one
command:

```bash
mapi lamb \
  --bam-dir ./bams \
  --require-index \
  --mapping-mapq 20 \
  --length-strata 20 \
  --min-read-length 1000 \
  --max-read-length 100000 \
  --min-bin-molecules 10 \
  --sparse-bin-policy merge \
  --mode maximalist \
  --seed 0 \
  --threads 4 \
  --out-dir .out/
```

Physical downsampling remains optional. Add `--materialize-bams` to that full
command, or materialize later without rerunning the model:

```bash
mapi lamb materialize \
  --out-dir .out/ \
  --threads 4
```

The physical BAMs and BAIs are written under
`07_materialized_bams/`. Selection is not rerandomized: LAMB keeps every BAM
record whose query name belongs to a molecule already marked
`virtual_selected=1`. It verifies the selected primary-molecule count, creates
an index, and runs `samtools quickcheck` before recording a `PASS` checkpoint.

The same command can be repeated. Valid stages are skipped. Once inventory
exists, `mapi lamb --out-dir .out/` can resume the remaining stages without
rediscovering BAMs. When omitted during a resume, LAMB reuses the existing
length-bin count, allocation mode, seed, and report resolution.

The read-length limits are applied during stratification, not BAM inventory,
so changing them does not require rereading the BAMs. `--min-bin-molecules 1`
is the default. Under the default `--sparse-bin-policy merge`, LAMB merges
adjacent candidate length bins until every final bin reaches that count in
every sample. This protects short- and long-read tails from becoming
zero-weight bins while retaining one feasible common target distribution.
`--sparse-bin-policy deactivate` preserves the LAMB 1.3 behavior, where bins
below the threshold remain visible but receive zero target and weight.

Because these options change the normalization model, changing them in an
existing output directory requires `--overwrite`; the existing molecule
inventory is still reused when BAM inputs are omitted. For example, to rebuild
an existing run with adaptive merging without rereading BAMs:

```bash
mapi lamb \
  --out-dir .out/ \
  --sparse-bin-policy merge \
  --overwrite
```

The runner reuses the existing length range, requested candidate-bin count,
occupancy threshold, allocation mode, and seed unless they are supplied again.

`balance` remains available as a compatibility shortcut for `allocate` plus
`manifest`.

The retired genomic-window meanings of `prepare`, `allocate`, `aggregate`,
`mask`, and `model` are not used by molecule-centric LAMB. The current
`allocate` command is a new read-length allocation solver.

## Existing `.out/` directory

The old inventory summary has an incompatible schema. Rebuild the inventory
once with `--overwrite`:

```bash
mapi lamb inventory \
  --bam-dir ./bams \
  --require-index \
  --mapping-mapq 20 \
  --threads 4 \
  --out-dir .out/ \
  --overwrite
```

Then run:

```bash
mapi lamb stratify \
  --out-dir .out/ \
  --length-strata 20

mapi lamb allocate \
  --mode minimalist \
  --seed 0 \
  --out-dir .out/

mapi lamb manifest \
  --out-dir .out/

mapi lamb validate \
  --out-dir .out/

mapi lamb report \
  --out-dir .out/
```

Use `--mode maximalist` to maximize worst-sample retention while preserving a
common target length distribution. Both modes reuse the same fixed shared
length-bin edges from `stratify`.

The old genomic-window files can remain in `.out/`; LAMB 1.0 ignores them. New
stage summaries use versioned schemas, so future identical runs are skipped by
the normal checkpoint system.

## Mapping policy

Mapping measurements remain in inventory, composition, balance, and molecule
allocation and manifest outputs as diagnostics. They do not change
`retention_probability` or `normalization_weight`. Consequently, lowering
`--mapping-mapq` does not change sparse-bin support or prevent a zero-weight
tail.

## Adaptive-bin output and report

`length_strata.tsv` now reports `candidate_strata_merged` and
`minimum_sample_molecules` for every final shared bin. The stratification log
reports both candidate and final bin counts. In adaptive-merge mode, allocation
fails immediately if a final bin is below the requested threshold or receives
a zero target fraction, and validation repeats the all-bins-active check.

The end of `06_report/lamb_report.html` contains a tiled per-sample section.
Each tile uses its own y-axis scale and overlays the corrected target
molecule-equivalent profile on the original per-bin molecule-count bars. The
individual PNGs are also available in `06_report/per_sample/`.
